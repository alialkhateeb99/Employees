﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeProject
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        
        public Form1()
        {
            InitializeComponent();
            string ConString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\alial\\OneDrive\\Documents\\employeeProject\\EmployeeProject\\EmployeeProject\\EmployeeDatabase.mdf;Integrated Security=True";
            con = new SqlConnection(ConString);
            con.Open();

        }

        private void button1_Click(object sender, EventArgs e)
        {
        string sql = "Insert Into MyTable (Id,FirstName,LastName,PhoneNumber,Address,City,State,Country,PostalCode) values('" + textBox9.Text + "','" + textBox1.Text +   "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text +  "','" + textBox5.Text +  "','" + textBox6.Text  +"','" + textBox7.Text +"','" + textBox8.Text +  "')";


            SqlCommand cmd = new SqlCommand(sql, con);

            int i = cmd.ExecuteNonQuery();

            con.Close();

            if (i != 0) {
                MessageBox.Show(i + " Data Saved");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
           string ConString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\alial\\OneDrive\\Documents\\employeeProject\\EmployeeProject\\EmployeeProject\\EmployeeDatabase.mdf;Integrated Security=True";
           SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT * FROM MyTable";

            SqlCommand cmd = new SqlCommand(query, con);
            var reader = cmd.ExecuteReader();

            DataTable table = new DataTable();
            table.Load(reader);

            dataGridView1.DataSource= table;    
            //reader.Close(); 

            con.Close();
    
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }


    }
}
